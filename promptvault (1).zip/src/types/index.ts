export interface PromptVersion {
  id: string;
  title: string;
  content: string;
  tags: string[];
  topic?: string;
  target?: string;
  tone?: string;
  createdAt: number;
}

export interface Prompt {
  id: string;
  title: string;
  content: string;
  folderId: string | null;
  tags: string[];
  topic?: string;
  target?: string;
  tone?: string;
  createdAt: number;
  updatedAt: number;
  source?: string;
  rating?: number;
  usageCount?: number;
  versions?: PromptVersion[];
}

export interface Folder {
  id: string;
  name: string;
  createdAt: number;
}
