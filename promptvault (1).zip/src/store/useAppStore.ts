import { useState, useEffect, useCallback } from 'react';
import { Prompt, Folder } from '../types';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  setDoc,
  serverTimestamp,
  getDocFromServer
} from 'firebase/firestore';
import { db } from '../lib/firebase';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export function useAppStore(userId: string | undefined) {
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [loading, setLoading] = useState(true);

  // Sync Folders
  useEffect(() => {
    if (!userId) {
      setFolders([]);
      return;
    }

    const q = query(collection(db, 'folders'), where('userId', '==', userId));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const folderList: Folder[] = [];
      snapshot.forEach((doc) => {
        folderList.push({ id: doc.id, ...doc.data() } as Folder);
      });
      setFolders(folderList);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'folders');
    });

    return unsubscribe;
  }, [userId]);

  // Sync Prompts
  useEffect(() => {
    if (!userId) {
      setPrompts([]);
      setLoading(false);
      return;
    }

    const q = query(collection(db, 'prompts'), where('userId', '==', userId));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const promptList: Prompt[] = [];
      snapshot.forEach((doc) => {
        promptList.push({ id: doc.id, ...doc.data() } as Prompt);
      });
      setPrompts(promptList.sort((a, b) => b.createdAt - a.createdAt));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'prompts');
    });

    return unsubscribe;
  }, [userId]);

  const addPrompt = useCallback(async (promptData: Omit<Prompt, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (!userId) return;
    const path = 'prompts';
    try {
      const now = Date.now();
      const newPrompt = {
        ...promptData,
        userId,
        createdAt: now,
        updatedAt: now,
        usageCount: 0,
        rating: 0
      };
      const docRef = await addDoc(collection(db, path), newPrompt);
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }, [userId]);

  const updatePrompt = useCallback(async (id: string, updates: Partial<Omit<Prompt, 'id' | 'createdAt' | 'updatedAt'>>) => {
    if (!userId) return;
    const path = `prompts/${id}`;
    try {
      const existingPrompt = prompts.find(p => p.id === id);
      if (!existingPrompt) return;

      const contentChanged = updates.content !== undefined && updates.content !== existingPrompt.content;
      const titleChanged = updates.title !== undefined && updates.title !== existingPrompt.title;
      const tagsChanged = updates.tags !== undefined && JSON.stringify(updates.tags) !== JSON.stringify(existingPrompt.tags);
      
      let newVersions = existingPrompt.versions || [];
      if (contentChanged || titleChanged || tagsChanged) {
        newVersions = [
          {
            id: crypto.randomUUID(),
            title: existingPrompt.title,
            content: existingPrompt.content,
            tags: existingPrompt.tags,
            topic: existingPrompt.topic,
            target: existingPrompt.target,
            tone: existingPrompt.tone,
            createdAt: existingPrompt.updatedAt,
          },
          ...newVersions,
        ];
      }

      await updateDoc(doc(db, 'prompts', id), {
        ...updates,
        versions: newVersions,
        updatedAt: Date.now()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }, [userId, prompts]);

  const incrementUsageCount = useCallback(async (id: string) => {
    if (!userId) return;
    const prompt = prompts.find(p => p.id === id);
    if (!prompt) return;
    try {
      await updateDoc(doc(db, 'prompts', id), {
        usageCount: (prompt.usageCount || 0) + 1
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `prompts/${id}`);
    }
  }, [userId, prompts]);

  const setRating = useCallback(async (id: string, rating: number) => {
    if (!userId) return;
    try {
      await updateDoc(doc(db, 'prompts', id), { rating });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `prompts/${id}`);
    }
  }, [userId]);

  const deletePrompt = useCallback(async (id: string) => {
    if (!userId) return;
    try {
      await deleteDoc(doc(db, 'prompts', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `prompts/${id}`);
    }
  }, [userId]);

  const addFolder = useCallback(async (name: string) => {
    if (!userId) return;
    try {
      const docRef = await addDoc(collection(db, 'folders'), {
        name,
        userId,
        createdAt: Date.now()
      });
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'folders');
    }
  }, [userId]);

  const deleteFolder = useCallback(async (id: string) => {
    if (!userId) return;
    try {
      await deleteDoc(doc(db, 'folders', id));
      // Optionally move prompts to "No Folder"
      const promptsInFolder = prompts.filter(p => p.folderId === id);
      for (const p of promptsInFolder) {
        await updateDoc(doc(db, 'prompts', p.id), { folderId: null });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `folders/${id}`);
    }
  }, [userId, prompts]);

  // Connection Test
  useEffect(() => {
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    };
    testConnection();
  }, []);

  return {
    prompts,
    folders,
    loading,
    addPrompt,
    updatePrompt,
    deletePrompt,
    addFolder,
    deleteFolder,
    incrementUsageCount,
    setRating,
  };
}
