import React, { useState, useEffect, useMemo } from 'react';
import { Folder, Prompt, PromptVersion } from '../types';
import { X, Save, Tag, Folder as FolderIcon, History as HistoryIcon, Sparkles, Target, Mic, BookOpen, Wand2, Type, Copy, Check } from 'lucide-react';
import { VersionHistoryModal } from './VersionHistoryModal';
import { useAudio } from '../hooks/useAudio';
import { motion, AnimatePresence } from 'motion/react';

interface PromptEditorProps {
  prompt?: Prompt | null;
  folders: Folder[];
  currentFolderId: string | null;
  onSave: (prompt: Omit<Prompt, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdate: (id: string, prompt: Partial<Omit<Prompt, 'id' | 'createdAt' | 'updatedAt'>>) => void;
  onClose: () => void;
}

export function PromptEditor({ prompt, folders, currentFolderId, onSave, onUpdate, onClose }: PromptEditorProps) {
  const [title, setTitle] = useState(prompt?.title || '');
  const [content, setContent] = useState(prompt?.content || '');
  const [folderId, setFolderId] = useState<string | null>(prompt?.folderId || currentFolderId);
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>(prompt?.tags || []);
  
  const [topic, setTopic] = useState(prompt?.topic || '');
  const [target, setTarget] = useState(prompt?.target || '');
  const [tone, setTone] = useState(prompt?.tone || '');
  
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isAILoading, setIsAILoading] = useState(false);
  const [isRefining, setIsRefining] = useState(false);
  const [refineInstruction, setRefineInstruction] = useState('');
  
  const [variableValues, setVariableValues] = useState<Record<string, string>>({});
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const { playBoo, playPong, playTutu } = useAudio();

  const variables = useMemo(() => {
    const matches = content.match(/\[(.*?)\]/g) || [];
    return Array.from(new Set(matches.map(m => m.slice(1, -1))));
  }, [content]);

  const previewContent = useMemo(() => {
    let result = content;
    Object.entries(variableValues).forEach(([variable, value]) => {
      const regex = new RegExp(`\\[${variable.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\]`, 'g');
      result = result.replace(regex, value || `[${variable}]`);
    });
    return result;
  }, [content, variableValues]);

  useEffect(() => {
    if (prompt) {
      setTitle(prompt.title);
      setContent(prompt.content);
      setFolderId(prompt.folderId);
      setTags(prompt.tags);
      setTopic(prompt.topic || '');
      setTarget(prompt.target || '');
      setTone(prompt.tone || '');
    } else {
      setTitle('');
      setContent('');
      setFolderId(currentFolderId);
      setTags([]);
      setTopic('');
      setTarget('');
      setTone('');
    }
  }, [prompt, currentFolderId]);

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && tagInput.trim()) {
      e.preventDefault();
      if (!tags.includes(tagInput.trim())) {
        setTags([...tags, tagInput.trim()]);
      }
      setTagInput('');
    }
  };

  const removeTag = (tToRemove: string) => {
    setTags(tags.filter(t => t !== tToRemove));
  };

  const handleSave = () => {
    if (!title.trim() || !content.trim()) return;
    playTutu();

    if (prompt) {
      onUpdate(prompt.id, { title, content, folderId, tags, topic, target, tone });
    } else {
      onSave({ title, content, folderId, tags, topic, target, tone });
    }
    onClose();
  };

  const handleDiscard = () => {
    playBoo();
    onClose();
  };

  const handleRestore = (version: PromptVersion) => {
    setTitle(version.title);
    setContent(version.content);
    setTags(version.tags);
    setTopic(version.topic || '');
    setTarget(version.target || '');
    setTone(version.tone || '');
    setIsHistoryOpen(false);
  };
  
  const autoExtractWithAI = async () => {
    if (!content.trim()) return;
    setIsAILoading(true);
    playPong();
    
    try {
      const { extractPromptMetadata } = await import('../services/geminiService');
      const metadata = await extractPromptMetadata(content);
      
      setTopic(metadata.topic);
      setTarget(metadata.target);
      setTone(metadata.tone);
      playTutu();
    } catch (error) {
      console.error("AI extraction failed:", error);
    } finally {
      setIsAILoading(false);
    }
  };

  const handleRefine = async () => {
    if (!content.trim() || !refineInstruction.trim()) return;
    setIsRefining(true);
    playPong();

    try {
      const { refinePrompt } = await import('../services/geminiService');
      const refined = await refinePrompt(content, refineInstruction);
      setContent(refined);
      setRefineInstruction('');
      playTutu();
    } catch (error) {
      console.error("AI refinement failed:", error);
    } finally {
      setIsRefining(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(isPreviewMode ? previewContent : content);
    setIsCopied(true);
    playTutu();
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col bg-white z-10 w-full overflow-hidden absolute inset-0 md:relative">
      <header className="h-12 flex items-center justify-between px-4 shrink-0 mt-2">
        <div className="flex items-center gap-2 text-sm text-slate-500 font-medium">
          <span className="cursor-pointer hover:bg-slate-100 px-1.5 py-0.5 rounded transition-colors" onClick={onClose}>PromptVault</span>
          <span className="text-slate-300">/</span>
          <span className="text-slate-900 truncate max-w-[200px]">{title || 'Untitled'}</span>
        </div>
        <div className="flex items-center gap-2">
          {variables.length > 0 && (
            <button
              onClick={() => {
                setIsPreviewMode(!isPreviewMode);
                playPong();
              }}
              className={`px-3 py-1.5 text-sm font-medium rounded transition-colors flex items-center gap-2 ${
                isPreviewMode ? 'bg-indigo-600 text-white' : 'text-slate-500 hover:bg-slate-100'
              }`}
            >
              <Type size={16} /> {isPreviewMode ? 'Editing' : 'Fill Variables'}
            </button>
          )}
          {prompt && prompt.versions && prompt.versions.length > 0 && (
            <button
              onClick={() => {
                setIsHistoryOpen(true);
                playPong();
              }}
              className="px-2 py-1.5 text-sm font-medium text-slate-500 hover:bg-slate-100 rounded transition-colors flex items-center gap-1.5"
              title="Version History"
            >
              <HistoryIcon size={16} /> <span className="hidden sm:inline">History</span>
            </button>
          )}
          <button onClick={handleDiscard} className="px-3 py-1.5 text-sm font-medium text-slate-500 hover:bg-slate-100 rounded transition-colors">
            Discard
          </button>
          <button
            onClick={handleSave}
            disabled={!title.trim() || !content.trim()}
            className="px-4 py-1.5 bg-slate-900 hover:bg-black disabled:opacity-50 text-white text-sm font-bold rounded-lg transition-all shadow-lg active:scale-95"
          >
            Save Page
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-6 md:px-24 lg:px-48 pt-12 pb-24 group/page">
        <input
          type="text"
          placeholder="Untitled"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full text-4xl font-bold text-slate-900 placeholder-slate-200 outline-none mb-6 bg-transparent"
        />

        <div className="space-y-3 mb-8 pb-8 border-b border-slate-100">
          <div className="flex items-center group/prop min-h-[32px]">
            <div className="w-32 flex items-center gap-2 text-slate-400 text-sm">
              <FolderIcon size={16} /> Folder
            </div>
            <div className="flex-1 max-w-sm">
              <select
                value={folderId || ''}
                onChange={(e) => setFolderId(e.target.value || null)}
                className="w-full bg-transparent text-sm text-slate-700 outline-none cursor-pointer hover:bg-slate-50 px-2 py-1 rounded transition-colors"
              >
                <option value="">Empty</option>
                {folders.map(f => (
                  <option key={f.id} value={f.id}>{f.name}</option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="flex items-center group/prop min-h-[32px]">
            <div className="w-32 flex items-center gap-2 text-slate-400 text-sm">
              <BookOpen size={16} /> Topic
            </div>
            <div className="flex-1 max-w-sm">
              <input
                type="text"
                placeholder="Empty"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full bg-transparent text-sm text-slate-700 outline-none hover:bg-slate-50 px-2 py-1 rounded transition-colors placeholder-slate-400"
              />
            </div>
          </div>
          
          <div className="flex items-center group/prop min-h-[32px]">
            <div className="w-32 flex items-center gap-2 text-slate-400 text-sm">
              <Target size={16} /> Target
            </div>
            <div className="flex-1 max-w-sm">
              <input
                type="text"
                placeholder="Empty"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                className="w-full bg-transparent text-sm text-slate-700 outline-none hover:bg-slate-50 px-2 py-1 rounded transition-colors placeholder-slate-400"
              />
            </div>
          </div>
          
          <div className="flex items-center group/prop min-h-[32px]">
            <div className="w-32 flex items-center gap-2 text-slate-400 text-sm">
              <Mic size={16} /> Tone
            </div>
            <div className="flex-1 max-w-sm">
              <input
                type="text"
                placeholder="Empty"
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full bg-transparent text-sm text-slate-700 outline-none hover:bg-slate-50 px-2 py-1 rounded transition-colors placeholder-slate-400"
              />
            </div>
          </div>

          <div className="flex items-start group/prop min-h-[32px]">
            <div className="w-32 flex items-center gap-2 text-slate-400 text-sm mt-1">
              <Tag size={16} /> Tags
            </div>
            <div className="flex-1 flex flex-wrap gap-1 items-center px-1">
              {tags.map(t => (
                <span key={t} className="flex items-center gap-1 bg-[#f1f1ef] text-slate-700 text-xs px-2 py-1 rounded">
                  {t}
                  <button onClick={() => removeTag(t)} className="opacity-50 hover:opacity-100 ml-1">
                    <X size={12} />
                  </button>
                </span>
              ))}
              <input
                type="text"
                placeholder={tags.length === 0 ? "Empty" : "Add..."}
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleAddTag}
                className="bg-transparent border-none outline-none text-sm min-w-[80px] max-w-full text-slate-700 placeholder-slate-400 hover:bg-slate-50 px-2 py-1 rounded transition-colors"
              />
            </div>
          </div>
        </div>
        
        <div className="mb-4">
          <button
            onClick={autoExtractWithAI}
            disabled={isAILoading || !content.trim()}
            className="flex items-center gap-2 text-sm text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors disabled:opacity-50 font-bold"
          >
            {isAILoading ? (
              <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <Sparkles size={16} />
            )}
            AI Meta-Extraction
          </button>
        </div>

        {isPreviewMode && variables.length > 0 ? (
          <div className="animate-in fade-in slide-in-from-top-2 duration-300">
             <div className="mb-8 p-6 bg-slate-50 rounded-2xl border border-slate-100">
               <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                 <Type size={16} className="text-indigo-500" /> Fill Template Variables
               </h3>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 {variables.map(variable => (
                   <div key={variable} className="space-y-1.5">
                     <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider ml-1">{variable}</label>
                     <input 
                       type="text"
                       placeholder={`Enter ${variable}...`}
                       value={variableValues[variable] || ''}
                       onChange={(e) => setVariableValues({...variableValues, [variable]: e.target.value})}
                       className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all"
                     />
                   </div>
                 ))}
               </div>
             </div>
             <div className="bg-[#1a1b1e] rounded-2xl p-8 text-slate-300 font-mono text-sm leading-relaxed border border-white/5 shadow-2xl relative group">
               <pre className="whitespace-pre-wrap break-words">{previewContent}</pre>
               <button 
                 onClick={copyToClipboard}
                 className="absolute top-4 right-4 bg-white/10 hover:bg-white/20 text-white p-2 rounded-xl backdrop-blur-md transition-all opacity-0 group-hover:opacity-100 flex items-center gap-2"
               >
                 {isCopied ? <Check size={16} className="text-green-400" /> : <Copy size={16} />}
                 <span className="text-xs font-bold">{isCopied ? 'Copied!' : 'Copy Filled'}</span>
               </button>
             </div>
          </div>
        ) : (
          <div className="relative group/textarea">
            <textarea
              placeholder="Start typing your prompt... Use [bracketed] text for variables."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onBlur={() => {
                if (content.trim() && !topic && !target && !tone) {
                  autoExtractWithAI();
                }
              }}
              className="w-full h-[60vh] text-slate-700 outline-none bg-transparent resize-none font-sans text-lg leading-relaxed placeholder-slate-200"
            />
            
            {/* AI Refiner Widget */}
            <div className="mt-8 pt-8 border-t border-slate-100">
               <div className="flex items-center gap-3 mb-4">
                 <div className="w-8 h-8 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-600">
                   <Wand2 size={18} />
                 </div>
                 <h4 className="text-sm font-bold text-slate-900">AI Prompt Refiner</h4>
               </div>
               <div className="flex gap-2">
                 <input 
                   type="text"
                   placeholder="e.g. 'Make it more professional', 'Add a hook', 'Shorten it'..."
                   value={refineInstruction}
                   onChange={(e) => setRefineInstruction(e.target.value)}
                   onKeyDown={(e) => e.key === 'Enter' && handleRefine()}
                   className="flex-1 bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm outline-none focus:bg-white focus:border-indigo-500 transition-all"
                 />
                 <button 
                   onClick={handleRefine}
                   disabled={isRefining || !content.trim() || !refineInstruction.trim()}
                   className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white px-6 py-3 rounded-xl text-sm font-bold shadow-lg shadow-indigo-600/20 transition-all flex items-center gap-2 shrink-0"
                 >
                   {isRefining ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Sparkles size={16} />}
                   Refine
                 </button>
               </div>
            </div>
          </div>
        )}
      </div>

      {prompt && (
        <VersionHistoryModal 
          isOpen={isHistoryOpen}
          onClose={() => setIsHistoryOpen(false)}
          prompt={prompt}
          onRestore={handleRestore}
        />
      )}
    </div>
  );
}
