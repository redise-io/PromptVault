import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, ChevronRight, Hash, Folder as FolderIcon, Plus, History, Sparkles } from 'lucide-react';
import { useAudio } from '../../hooks/useAudio';
import { Prompt, Folder } from '../../types';

interface ShortcutChatProps {
  prompts: Prompt[];
  folders: Folder[];
  onSelectPrompt: (prompt: Prompt) => void;
  onSelectFolder: (folderId: string | null) => void;
  onNewPrompt: () => void;
}

export function ShortcutChat({ prompts, folders, onSelectPrompt, onSelectFolder, onNewPrompt }: ShortcutChatProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ id: string; type: 'bot' | 'user'; text: string; options?: any[] }[]>([]);
  const { playBoo, playPong, playTutu } = useAudio();
  const scrollRef = useRef<HTMLDivElement>(null);

  const toggleOpen = () => {
    if (!isOpen) {
      playBoo();
    }
    setIsOpen(!isOpen);
  };

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setTimeout(() => {
        playTutu();
        setMessages([
          {
            id: '1',
            type: 'bot',
            text: 'Welcome! 👋 I can help you find your prompts quickly.',
            options: [
              { id: 'latest', label: 'Latest Prompts', icon: <History size={16} /> },
              { id: 'folders', label: 'My Folders', icon: <FolderIcon size={16} /> },
              { id: 'new', label: 'New Prompt', icon: <Plus size={16} />, primary: true }
            ]
          }
        ]);
      }, 500);
    }
  }, [isOpen, messages.length, playTutu]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleOptionClick = (optionId: string) => {
    playPong();
    if (optionId === 'latest') {
      const latest = prompts.slice(0, 5);
      setMessages(prev => [
        ...prev,
        { id: Date.now().toString() + 'u', type: 'user', text: 'Show latest prompts' },
        {
          id: Date.now().toString() + 'b',
          type: 'bot',
          text: 'Here are your most recent prompts:',
          options: latest.map(p => ({ id: `p-${p.id}`, label: p.title, data: p }))
        }
      ]);
    } else if (optionId === 'folders') {
      setMessages(prev => [
        ...prev,
        { id: Date.now().toString() + 'u', type: 'user', text: 'Browse folders' },
        {
          id: Date.now().toString() + 'b',
          type: 'bot',
          text: 'Which folder would you like to open?',
          options: [
            { id: 'f-null', label: 'All Prompts' },
            ...folders.map(f => ({ id: `f-${f.id}`, label: f.name }))
          ]
        }
      ]);
    } else if (optionId === 'new') {
      onNewPrompt();
      setIsOpen(false);
    } else if (optionId.startsWith('p-')) {
      const pId = optionId.replace('p-', '');
      const prompt = prompts.find(p => p.id === pId);
      if (prompt) {
        onSelectPrompt(prompt);
        setIsOpen(false);
      }
    } else if (optionId.startsWith('f-')) {
      const fId = optionId === 'f-null' ? null : optionId.replace('f-', '');
      onSelectFolder(fId);
      setIsOpen(false);
    }
  };

  const resetChat = () => {
    playPong();
    setMessages([
      {
        id: Date.now().toString(),
        type: 'bot',
        text: 'How can I help you next?',
        options: [
          { id: 'latest', label: 'Latest Prompts', icon: <History size={16} /> },
          { id: 'folders', label: 'My Folders', icon: <FolderIcon size={16} /> },
          { id: 'new', label: 'New Prompt', icon: <Plus size={16} />, primary: true }
        ]
      }
    ]);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60] flex flex-col items-end gap-4 pointer-events-none">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9, transformOrigin: 'bottom right' }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="w-[380px] h-[520px] bg-[#1a1b1e] rounded-3xl shadow-2xl overflow-hidden border border-white/10 pointer-events-auto flex flex-col"
          >
            {/* Header */}
            <div className="p-4 bg-[#25262b] border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500 flex items-center justify-center text-white shadow-lg">
                  <Sparkles size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white leading-tight">Prompt Assistant</h3>
                  <p className="text-[10px] text-indigo-300 font-medium tracking-wide uppercase">AI Powered Shortcut</p>
                </div>
              </div>
              <button 
                onClick={toggleOpen}
                className="p-2 text-white/40 hover:text-white hover:bg-white/5 rounded-xl transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Content */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-hide"
            >
              {messages.map((m) => (
                <div key={m.id} className={`flex flex-col gap-3 ${m.type === 'user' ? 'items-end' : 'items-start'}`}>
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed ${
                      m.type === 'user' 
                        ? 'bg-indigo-600 text-white rounded-tr-none' 
                        : 'bg-[#2c2e33] text-slate-200 rounded-tl-none shadow-sm border border-white/5'
                    }`}
                  >
                    {m.text}
                  </motion.div>
                  
                  {m.options && (
                    <div className="flex flex-wrap gap-2 pt-1 w-full">
                      {m.options.map((opt) => (
                        <motion.button
                          key={opt.id}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => handleOptionClick(opt.id)}
                          className={`flex items-center gap-2 px-4 py-3 rounded-xl text-xs font-semibold transition-all ${
                            opt.primary
                              ? 'bg-indigo-500 hover:bg-indigo-400 text-white shadow-lg shadow-indigo-500/20'
                              : 'bg-[#2c2e33] hover:bg-[#373940] text-slate-300 border border-white/5'
                          }`}
                        >
                          {opt.icon}
                          {opt.label}
                          {!opt.icon && <ChevronRight size={14} className="opacity-40" />}
                        </motion.button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="p-4 bg-[#25262b] border-t border-white/5 flex items-center justify-between">
               <span className="text-[10px] text-slate-500 font-medium">PROMPTVAULT BOT</span>
               <button 
                onClick={resetChat}
                className="text-[10px] bg-white/5 hover:bg-white/10 text-slate-300 px-3 py-1.5 rounded-full transition-colors font-bold uppercase tracking-wider"
               >
                 Start over
               </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={toggleOpen}
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-colors pointer-events-auto group relative ${
          isOpen ? 'bg-[#1a1b1e] text-indigo-400' : 'bg-indigo-600 text-white'
        }`}
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <X size={28} />
            </motion.div>
          ) : (
            <motion.div
              key="open"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <MessageSquare size={28} />
              {/* Badge simulation */}
              <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 rounded-full border-2 border-indigo-600 animate-pulse" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>
    </div>
  );
}
