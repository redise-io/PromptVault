import React, { useState } from 'react';
import { X, UploadCloud, FileJson, FileText, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppStore } from '../store/useAppStore';
import { useAuth } from '../lib/AuthContext';

interface BulkImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentFolderId: string | null;
}

export function BulkImportModal({ isOpen, onClose, currentFolderId }: BulkImportModalProps) {
  const { user } = useAuth();
  const { addPrompt, prompts } = useAppStore(user?.uid);
  const [isDragActive, setIsDragActive] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importStep, setImportStep] = useState<'upload' | 'analyzing' | 'done'>('upload');
  const [importResult, setImportResult] = useState<{ success: number; failed: number; duplicates: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(false);
  };

  const processFile = async (file: File) => {
    setIsImporting(true);
    setImportStep('analyzing');
    setError(null);
    setImportResult(null);

    try {
      const text = await file.text();
      let newPrompts: { title: string; content: string }[] = [];

      if (file.name.endsWith('.json')) {
        try {
          const parsed = JSON.parse(text);
          if (Array.isArray(parsed)) {
            newPrompts = parsed.map((item, index) => ({
              title: item.title || item.name || `Imported Prompt ${index + 1}`,
              content: item.content || item.prompt || item.text || '',
            }));
          } else {
            throw new Error('JSON strictly must be an array of objects.');
          }
        } catch (e) {
          throw new Error('Invalid JSON format.');
        }
      } else if (file.name.endsWith('.txt')) {
        // split by double newlines
        const blocks = text.split(/\n\s*\n/);
        newPrompts = blocks.filter(b => b.trim().length > 0).map((block, index) => {
          const lines = block.trim().split('\n');
          const title = lines.length > 1 && lines[0].length < 100 ? lines[0] : `Imported Block ${index + 1}`;
          const content = lines.length > 1 && lines[0].length < 100 ? lines.slice(1).join('\n') : block;
          return { title, content };
        });
      } else {
        throw new Error('Unsupported file format. Please upload .json or .txt files.');
      }

      // Filter valid
      const validPrompts = newPrompts.filter(p => p.content && p.content.trim().length > 0);
      
      // Simulate AI Deduplication
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      let successCount = 0;
      let duplicateCount = 0;
      
      validPrompts.forEach(p => {
        // Simple duplicate detection: check if content exists or is >90% similar (mocked here by simple includes)
        const isDuplicate = prompts.some(
          existing => existing.content.toLowerCase().includes(p.content.toLowerCase()) || p.content.toLowerCase().includes(existing.content.toLowerCase())
        );
        
        if (isDuplicate) {
          duplicateCount++;
        } else {
          addPrompt({
            title: p.title,
            content: p.content,
            tags: ['Imported', 'AI-Processed'],
            folderId: currentFolderId
          });
          successCount++;
        }
      });

      setImportResult({ success: successCount, failed: newPrompts.length - validPrompts.length, duplicates: duplicateCount });
      setImportStep('done');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      setImportStep('upload');
    } finally {
      setIsImporting(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden border border-slate-200"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
            <h2 className="text-lg font-bold text-slate-800">Bulk Import Prompts</h2>
            <button onClick={onClose} className="p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 rounded transition-colors">
              <X size={20} />
            </button>
          </div>

          <div className="p-6">
            {!importResult && importStep === 'upload' ? (
              <div 
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors relative ${
                  isDragActive ? 'border-blue-500 bg-blue-50' : 'border-slate-300 bg-slate-50 hover:bg-slate-100'
                }`}
              >
                <input 
                  type="file" 
                  accept=".json,.txt"
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  disabled={isImporting}
                />
                
                <div className="flex flex-col items-center justify-center pointer-events-none">
                  <div className="w-12 h-12 rounded-full bg-white shadow-sm flex items-center justify-center mb-4">
                    <UploadCloud size={24} className="text-blue-500" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-800 mb-1">Click or drag file to this area</h3>
                  <p className="text-xs text-slate-500 max-w-[250px] mb-4">
                    Upload a JSON array of objects or a plain TXT file (blocks separated by generic spaces).
                  </p>
                  
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1.5 px-2 py-1 bg-white border border-slate-200 rounded text-[10px] font-bold text-slate-600 uppercase shadow-sm">
                      <FileJson size={12} className="text-orange-500" />
                      .JSON
                    </span>
                    <span className="flex items-center gap-1.5 px-2 py-1 bg-white border border-slate-200 rounded text-[10px] font-bold text-slate-600 uppercase shadow-sm">
                      <FileText size={12} className="text-blue-500" />
                      .TXT
                    </span>
                  </div>
                </div>
              </div>
            ) : importStep === 'done' && importResult ? (
              <div className="text-center py-6 animate-in zoom-in-95 duration-300">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4 border border-green-200">
                  <CheckCircle2 size={32} className="text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-2">Import Successful</h3>
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 mb-6 inline-block text-left shadow-sm">
                  <p className="text-sm font-semibold text-slate-700 flex justify-between gap-6 mb-1">
                    <span>Added:</span> <span className="text-green-600">{importResult.success}</span>
                  </p>
                  <p className="text-sm font-semibold text-slate-700 flex justify-between gap-6 mb-1">
                    <span>Duplicates (AI Removed):</span> <span className="text-orange-500">{importResult.duplicates}</span>
                  </p>
                  <p className="text-sm font-semibold text-slate-700 flex justify-between gap-6">
                    <span>Failed/Invalid:</span> <span className="text-red-500">{importResult.failed}</span>
                  </p>
                </div>
                <div>
                  <button 
                    onClick={() => {
                      setImportResult(null);
                      setImportStep('upload');
                      onClose();
                    }}
                    className="px-6 py-2 bg-slate-900 hover:bg-black text-white rounded-md font-medium text-sm transition-colors shadow-sm"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : null}

            {error && importStep === 'upload' && (
              <div className="mt-4 p-3 bg-red-50 border border-red-100 rounded-lg flex items-start gap-2">
                <AlertCircle size={16} className="text-red-600 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-red-800">{error}</p>
              </div>
            )}
            
            {importStep === 'analyzing' && (
              <div className="py-12 text-center animate-in fade-in duration-500">
                <div className="flex flex-col items-center gap-4">
                  <div className="relative w-12 h-12 flex items-center justify-center">
                    <div className="absolute inset-0 border-2 border-slate-100 rounded-full"></div>
                    <div className="absolute inset-0 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    <Sparkles size={20} className="text-blue-600 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-800 mb-1">AI Deduplication in Progress</h3>
                    <p className="text-xs text-slate-500 max-w-[250px] mx-auto">
                      Analyzing content to merge duplicates and skip identical imports...
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
