import React, { useState } from 'react';
import { Prompt, PromptVersion } from '../types';
import { X, Clock, ArrowLeft, History } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface VersionHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  prompt: Prompt;
  onRestore: (version: PromptVersion) => void;
}

export function VersionHistoryModal({ isOpen, onClose, prompt, onRestore }: VersionHistoryModalProps) {
  const versions = prompt.versions || [];
  const [selectedVersionId, setSelectedVersionId] = useState<string | null>(null);

  if (!isOpen) return null;

  const selectedVersion = versions.find(v => v.id === selectedVersionId) || versions[0];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-900/50 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl shadow-xl w-full max-w-5xl overflow-hidden border border-slate-200 flex flex-col md:flex-row h-[80vh] max-h-[800px]"
        >
          {/* Sidebar - Version List */}
          <div className="w-full md:w-80 bg-slate-50 border-r border-slate-200 flex flex-col shrink-0 h-1/3 md:h-full">
            <div className="flex items-center gap-2 p-4 border-b border-slate-200 bg-white shrink-0">
              <History size={18} className="text-slate-500" />
              <h2 className="font-semibold text-slate-800">Version History</h2>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {versions.length === 0 ? (
                <div className="text-sm text-slate-500 text-center mt-8">
                  No previous versions yet.
                </div>
              ) : (
                versions.map(v => (
                  <button
                    key={v.id}
                    onClick={() => setSelectedVersionId(v.id)}
                    className={`w-full text-left p-3 rounded-xl border transition-colors ${
                      (selectedVersionId === v.id || (!selectedVersionId && versions[0] === v))
                        ? 'bg-white border-blue-200 shadow-sm'
                        : 'bg-transparent border-transparent hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-1">
                      <Clock size={14} className="text-slate-400" />
                      {new Date(v.createdAt).toLocaleString(undefined, {
                        month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit'
                      })}
                    </div>
                    <div className="text-xs text-slate-500 truncate max-w-[200px]">
                      {v.title || 'Untitled'}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Main Content - Version Preview */}
          <div className="flex-1 flex flex-col min-w-0 bg-white h-2/3 md:h-full">
             <div className="flex items-center justify-between p-4 border-b border-slate-100 shrink-0">
               <div className="flex items-center gap-3">
                 <h3 className="font-semibold text-slate-800 hidden sm:block">Preview</h3>
                 {selectedVersion && (
                   <span className="text-xs font-medium bg-slate-100 text-slate-500 px-2 py-1 rounded">
                     {new Date(selectedVersion.createdAt).toLocaleString(undefined, {
                        month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit'
                      })}
                   </span>
                 )}
               </div>
               <div className="flex items-center gap-2">
                 <button 
                  onClick={onClose} 
                  className="p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 rounded-md transition-colors sm:hidden"
                 >
                   <X size={20} />
                 </button>
                 {selectedVersion && (
                   <button
                     onClick={() => onRestore(selectedVersion)}
                     className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-black text-white text-sm font-medium rounded-lg transition-colors"
                   >
                     <ArrowLeft size={16} /> Restore this version
                   </button>
                 )}
                 <button 
                  onClick={onClose} 
                  className="p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 rounded-md transition-colors hidden sm:block"
                 >
                   <X size={20} />
                 </button>
               </div>
             </div>

             <div className="flex-1 overflow-y-auto p-6 md:p-8">
                {selectedVersion ? (
                  <div className="max-w-3xl mx-auto space-y-6">
                    <h1 className="text-3xl font-bold text-slate-900">
                      {selectedVersion.title || 'Untitled'}
                    </h1>
                    
                    {selectedVersion.tags.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {selectedVersion.tags.map(t => (
                          <span key={t} className="bg-[#f1f1ef] text-slate-600 text-xs px-2 py-1 rounded">
                            {t}
                          </span>
                        ))}
                      </div>
                    )}

                    <div className="prose prose-slate max-w-none">
                      <pre className="whitespace-pre-wrap font-sans text-base text-slate-700 bg-transparent border-none p-0 overflow-visible">
                        {selectedVersion.content}
                      </pre>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center text-slate-400">
                    Select a version to preview
                  </div>
                )}
             </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
