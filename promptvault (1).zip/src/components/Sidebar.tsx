import React, { useState } from 'react';
import { Folder as FolderIcon, Plus, Hash, Settings, LayoutGrid } from 'lucide-react';
import { Folder } from '../types';
import { cn } from '../lib/utils';

interface SidebarProps {
  folders: Folder[];
  tags: string[];
  currentFolderId: string | null;
  currentTag: string | null;
  onSelectFolder: (id: string | null) => void;
  onSelectTag: (tag: string | null) => void;
  onAddFolder: (name: string) => void;
  onOpenSettings: () => void;
}

export function Sidebar({ folders, tags, currentFolderId, currentTag, onSelectFolder, onSelectTag, onAddFolder, onOpenSettings }: SidebarProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newFolderName.trim()) {
      onAddFolder(newFolderName.trim());
      setNewFolderName('');
      setIsAdding(false);
    }
  };

  return (
    <aside className="w-64 flex-shrink-0 bg-[#F7F7F5] border-r border-[#E9E9E7] flex flex-col h-full font-sans text-sm">
      <div className="p-4 flex items-center gap-2 hover:bg-[#EAEAEA] mx-2 mt-2 rounded transition-colors cursor-pointer">
        <div className="w-5 h-5 rounded bg-slate-800 flex items-center justify-center font-bold text-white text-xs">
          P
        </div>
        <h1 className="font-semibold text-slate-800 tracking-tight text-[14px]">PromptVault</h1>
      </div>

      <nav className="flex-1 overflow-y-auto px-2 mt-4 space-y-4">
        <div className="space-y-0.5">
          <button
            onClick={() => { onSelectFolder(null); onSelectTag(null); }}
            className={cn(
              "w-full flex items-center gap-2 px-2 py-1 rounded transition-colors text-[14px] font-medium",
              currentFolderId === null && currentTag === null
                ? "bg-[#EAEAEA] text-slate-900"
                : "text-slate-600 hover:bg-[#EAEAEA]"
            )}
          >
            <LayoutGrid size={16} className="text-slate-400" />
            All Prompts
          </button>
        </div>

        <div>
          <div className="flex items-center justify-between px-2 mb-1 group/section">
            <h2 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
              Folders
            </h2>
            <button
              onClick={() => setIsAdding(true)}
              className="text-slate-400 hover:bg-[#EAEAEA] p-0.5 rounded opacity-0 group-hover/section:opacity-100 transition-all"
            >
              <Plus size={14} />
            </button>
          </div>

          <div className="space-y-0.5 mt-1">
            {folders.map((folder) => (
              <button
                key={folder.id}
                onClick={() => { onSelectFolder(folder.id); onSelectTag(null); }}
                className={cn(
                  "w-full flex items-center gap-2 px-2 py-1 rounded transition-colors text-[14px] font-medium group",
                  currentFolderId === folder.id
                    ? "bg-[#EAEAEA] text-slate-900"
                    : "text-slate-600 hover:bg-[#EAEAEA]"
                )}
              >
                <div className="transition-transform group-hover:rotate-90">
                  <svg width="12" height="12" viewBox="0 0 100 100" className={cn("fill-current", currentFolderId === folder.id ? "text-slate-600 rotate-90" : "text-slate-400")}>
                    <polygon points="30,20 80,50 30,80" />
                  </svg>
                </div>
                {folder.name}
              </button>
            ))}

            {isAdding && (
              <form onSubmit={handleAddSubmit} className="px-5 py-1">
                <input
                  type="text"
                  autoFocus
                  placeholder="New folder..."
                  className="w-full bg-transparent border-b border-blue-400 px-1 py-0.5 text-[14px] text-slate-700 outline-none placeholder-slate-400"
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  onBlur={() => setIsAdding(false)}
                />
              </form>
            )}
          </div>
        </div>

        {tags.length > 0 && (
          <div>
            <h2 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider px-2 mb-1">
              Collections
            </h2>
            <div className="space-y-0.5 mt-1">
              {tags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => { onSelectTag(tag); onSelectFolder(null); }}
                  className={cn(
                    "w-full flex items-center gap-2 px-2 py-1 rounded transition-colors text-[14px] font-medium",
                    currentTag === tag
                      ? "bg-[#EAEAEA] text-slate-900"
                      : "text-slate-600 hover:bg-[#EAEAEA]"
                  )}
                >
                  <Hash size={14} className="text-slate-400" />
                  {tag}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      <div className="p-2 mb-2">
        <button 
          onClick={onOpenSettings}
          className="w-full flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer hover:bg-[#EAEAEA] transition-colors"
        >
          <div className="w-5 h-5 flex items-center justify-center flex-shrink-0">
             <Settings size={16} className="text-slate-500" />
          </div>
          <div className="text-[14px] text-left text-slate-600 font-medium">
            Settings & Integrations
          </div>
        </button>
      </div>
    </aside>
  );
}
