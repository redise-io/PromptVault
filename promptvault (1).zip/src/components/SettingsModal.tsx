import React, { useState } from 'react';
import { X, Key, Webhook, Activity, Server, Copy, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppStore } from '../store/useAppStore';
import { useAuth } from '../lib/AuthContext';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const { user } = useAuth();
  const { addPrompt } = useAppStore(user?.uid);
  const [copiedKey, setCopiedKey] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [logs, setLogs] = useState<{ id: number; message: string; timestamp: string; status: 'success' | 'error' }[]>([]);

  if (!isOpen) return null;

  const apiKey = 'pk_live_d92j8f3nf938jd9n28dn';

  const copyKey = async () => {
    await navigator.clipboard.writeText(apiKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const simulateWebhook = () => {
    setIsSimulating(true);
    
    // Simulate network delay
    setTimeout(() => {
      addPrompt({
        title: 'Lead Gen Follow-up',
        content: 'Hi [Name],\n\nI noticed you joined our webinar on [Topic]. What was your biggest takeaway?\n\nCheers,\n[My_Name]',
        tags: ['Sales', 'Webinar', 'API'],
        folderId: null,
      });

      const newLog = {
        id: Date.now(),
        message: 'POST /api/v1/prompts - 201 Created',
        timestamp: new Date().toLocaleTimeString(),
        status: 'success' as const
      };
      
      setLogs(prev => [newLog, ...prev]);
      setIsSimulating(false);
    }, 1500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[90vh]"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50 shrink-0">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Server size={20} className="text-blue-600" />
              API Simulator & Settings
            </h2>
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700 rounded-md transition-colors">
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 md:p-8 flex flex-col gap-8 bg-white">
            
            {/* API Keys */}
            <section className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-1">
                  <Key size={16} className="text-blue-600" />
                  API Keys
                </h3>
                <p className="text-xs text-slate-500">
                  Use these keys to authenticate your requests via Zapier, Make, or custom integrations.
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
                <div className="flex-1 overflow-hidden">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 block">Live Secret Key</label>
                  <code className="text-sm font-mono text-slate-800 truncate block">pk_live_************************</code>
                </div>
                <button 
                  onClick={copyKey}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded shadow-sm hover:bg-slate-50 transition-colors"
                >
                  {copiedKey ? <Check size={14} className="text-green-600" /> : <Copy size={14} />}
                  Copy
                </button>
              </div>
            </section>

            <hr className="border-slate-100" />

            {/* Webhook Simulator */}
            <section className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-1">
                  <Webhook size={16} className="text-purple-600" />
                  Webhook Simulator
                </h3>
                <p className="text-xs text-slate-500">
                  Test your inbound ingestion path. Simulates a POST request from an external service.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-[#1E1E1E] rounded-xl p-4 overflow-hidden relative">
                  <div className="flex items-center justify-between mb-3">
                     <span className="text-xs font-bold text-slate-400 font-mono">POST /api/v1/prompts</span>
                     <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">Payload</span>
                  </div>
                  <pre className="text-xs font-mono text-green-400 whitespace-pre-wrap">
{`{
  "title": "Lead Gen Follow-up",
  "content": "Hi [Name],\\n\\nI noticed you joined...",
  "tags": ["Sales", "Webinar", "API"]
}`}
                  </pre>
                </div>
                
                <div className="flex flex-col justify-end gap-3">
                  <button
                    onClick={simulateWebhook}
                    disabled={isSimulating}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-slate-900 hover:bg-black text-white rounded-xl shadow-sm font-semibold transition-all disabled:opacity-50"
                  >
                    {isSimulating ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                         <Activity size={18} />
                         Trigger Webhook
                      </>
                    )}
                  </button>
                  <p className="text-[10px] text-center text-slate-400">
                    Clicking this will instantly push a new prompt to your workspace.
                  </p>
                </div>
              </div>
            </section>

            {/* Activity Logs */}
            {logs.length > 0 && (
              <section className="space-y-4 mt-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
                 <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-1">
                    Activity Logs
                 </h3>
                 <div className="space-y-2">
                   {logs.map((log) => (
                     <div key={log.id} className="flex items-center gap-3 text-xs bg-slate-50 border border-slate-200 rounded-lg p-3">
                       <span className="text-slate-400 font-mono w-20">{log.timestamp}</span>
                       <span className="flex-1 font-mono text-slate-700">{log.message}</span>
                       <span className="text-green-600 font-bold bg-green-100 px-2 py-0.5 rounded uppercase text-[10px]">Success</span>
                     </div>
                   ))}
                 </div>
              </section>
            )}

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
