import React, { useState, useMemo } from 'react';
import { Prompt } from '../types';
import { Copy, Edit2, Trash2, CheckCircle2, Star, Activity } from 'lucide-react';
import { cn } from '../lib/utils';
import { useAudio } from '../hooks/useAudio';
import { motion } from 'motion/react';

interface PromptCardProps {
  prompt: Prompt;
  onEdit: (prompt: Prompt) => void;
  onDelete: (id: string) => void;
  onRate: (id: string, rating: number) => void;
  onCopyAction: (id: string) => void;
}

export const PromptCard: React.FC<PromptCardProps> = ({ prompt, onEdit, onDelete, onRate, onCopyAction }) => {
  const [copied, setCopied] = useState(false);
  const [variableValues, setVariableValues] = useState<Record<string, string>>({});
  const { playBoo, playPong, playTutu } = useAudio();

  // Detect [variables] in the prompt content
  const variables = useMemo(() => {
    const regex = /\[([^[\]]+)\]/g;
    const matches = Array.from(prompt.content.matchAll(regex));
    const uniqueVars = Array.from(new Set(matches.map(m => m[1])));
    return uniqueVars;
  }, [prompt.content]);

  // Generate final content substituting variables
  const finalContent = useMemo(() => {
    let result = prompt.content;
    variables.forEach(v => {
      const val = variableValues[v];
      if (val) {
        result = result.replaceAll(`[${v}]`, val);
      }
    });
    return result;
  }, [prompt.content, variables, variableValues]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(finalContent);
      setCopied(true);
      playTutu();
      onCopyAction(prompt.id);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error('Failed to copy', e);
    }
  };

  const handleVarChange = (vari: string, val: string) => {
    setVariableValues(prev => ({ ...prev, [vari]: val }));
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white border border-slate-200 rounded-md p-4 hover:shadow-md transition-shadow flex flex-col gap-3 min-h-[160px] group cursor-pointer relative overflow-hidden"
      onClick={() => onEdit(prompt)}
    >
      <div className="flex items-start justify-between">
        <h3 className="font-semibold text-slate-800 line-clamp-2 text-sm">
          <span className="mr-2 opacity-50">📄</span>
          {prompt.title || 'Untitled'}
        </h3>
        
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => { 
              e.stopPropagation(); 
              playBoo();
              onDelete(prompt.id); 
            }}
            className="p-1 text-slate-400 hover:text-red-500 rounded hover:bg-slate-100 transition-colors"
            title="Delete"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      <div className="flex-1 text-xs text-slate-500 line-clamp-3 leading-relaxed font-serif">
        {finalContent || "Empty"}
      </div>

      <div className="flex items-center justify-between mt-2 pt-3 border-t border-slate-100">
        <div className="flex items-center gap-2">
          {/* Star Rating System */}
          <div className="flex items-center" onClick={(e) => e.stopPropagation()}>
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={(e) => {
                  e.stopPropagation();
                  onRate(prompt.id, star === prompt.rating ? 0 : star);
                }}
                className="p-[1px]"
              >
                <Star 
                  size={12} 
                  className={cn(
                    "transition-colors",
                    (prompt.rating || 0) >= star ? "fill-yellow-400 text-yellow-400" : "fill-transparent text-slate-200 hover:text-yellow-200"
                  )} 
                />
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {prompt.usageCount ? (
              <span className="flex items-center gap-1 text-[10px] text-slate-400 font-medium">
                <Activity size={10} />
                {prompt.usageCount}
              </span>
            ) : null}
            {prompt.tags.slice(0, 2).map((t, i) => (
              <span key={i} className="text-[10px] text-slate-500 px-1.5 py-0.5 bg-[#f1f1ef] min-w-0 truncate max-w-[80px] rounded">
                {t}
              </span>
            ))}
          </div>
        </div>

        <button
          onClick={(e) => { e.stopPropagation(); handleCopy(); }}
          className={cn(
            "flex items-center justify-center p-1.5 rounded transition-colors shadow-sm",
            copied 
              ? "bg-green-100 text-green-700 border border-green-200" 
              : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
          )}
          title="Copy to Clipboard"
        >
          {copied ? <CheckCircle2 size={12} /> : <Copy size={12} />}
        </button>
      </div>

      {/* Variables form - shown only if there are variables and we're hovering */}
      {variables.length > 0 && (
        <div 
          className="absolute inset-x-0 bottom-0 bg-white border-t border-slate-200 p-3 translate-y-[100%] group-hover:translate-y-0 transition-transform shadow-lg"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-[10px] font-bold text-slate-700 uppercase tracking-wider">Variables</h4>
            <button
              onClick={(e) => { e.stopPropagation(); handleCopy(); }}
              className="text-xs bg-slate-900 text-white px-2 py-0.5 rounded flex items-center gap-1"
            >
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2 max-h-[80px] overflow-y-auto">
            {variables.map(v => (
              <div key={v}>
                <input
                  type="text"
                  placeholder={v}
                  value={variableValues[v] || ''}
                  onChange={(e) => handleVarChange(v, e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded px-1.5 py-1 text-[10px] text-slate-700 focus:outline-none focus:border-slate-400"
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}
