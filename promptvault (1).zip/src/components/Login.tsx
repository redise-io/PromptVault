import React from 'react';
import { useAuth } from '../lib/AuthContext';
import { motion } from 'motion/react';
import { Github, Chrome } from 'lucide-react';

export function Login() {
  const { signInWithGoogle, signInWithGithub } = useAuth();

  return (
    <div className="min-h-screen bg-[#F7F7F5] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 border border-slate-200"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-slate-900 flex items-center justify-center font-bold text-white text-3xl mx-auto mb-4 shadow-lg">
            P
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Welcome to PromptVault</h1>
          <p className="text-slate-500 text-sm">Your intelligent personal prompt companion.</p>
        </div>

        <div className="space-y-4">
          <button
            onClick={signInWithGoogle}
            className="w-full flex items-center justify-center gap-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-medium py-3 rounded-xl transition-all shadow-sm group"
          >
            <Chrome size={20} className="text-slate-400 group-hover:text-slate-600 transition-colors" />
            Continue with Google
          </button>

          <button
            onClick={signInWithGithub}
            className="w-full flex items-center justify-center gap-3 bg-slate-900 hover:bg-black text-white font-medium py-3 rounded-xl transition-all shadow-lg group"
          >
            <Github size={20} className="text-white opacity-80 group-hover:opacity-100 transition-opacity" />
            Continue with GitHub
          </button>
        </div>

        <p className="mt-8 text-center text-xs text-slate-400">
          By signing in, you agree to our Terms of Service <br /> and Privacy Policy.
        </p>
      </motion.div>
    </div>
  );
}
