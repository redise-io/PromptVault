import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function extractPromptMetadata(content: string): Promise<{ topic: string, target: string, tone: string }> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following prompt content and extract its core topic, target audience, and intended tone. \n\nPrompt content:\n"""\n${content}\n"""`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          topic: {
            type: Type.STRING,
            description: "The core topic or subject matter of the prompt (max 3 words).",
          },
          target: {
            type: Type.STRING,
            description: "The intended target audience for the prompt (e.g., 'General Audience', 'B2B Leads', 'Developers').",
          },
          tone: {
            type: Type.STRING,
            description: "The overall tone of the prompt (e.g., 'Professional', 'Persuasive', 'Informative', 'Casual').",
          },
        },
        required: ["topic", "target", "tone"],
      },
      temperature: 0.2, // Keep it deterministic
    },
  });

  try {
    const text = response.text || "";
    const parsed = JSON.parse(text);
    return {
      topic: parsed.topic || "General",
      target: parsed.target || "General Audience",
      tone: parsed.tone || "Neutral",
    };
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    return {
      topic: "General",
      target: "General Audience",
      tone: "Neutral",
    };
  }
}

export async function refinePrompt(content: string, instruction: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `You are an expert prompt engineer. Your task is to refine the following prompt based on the user instruction. 
    
    Original Prompt:
    """
    ${content}
    """
    
    Instruction: ${instruction}
    
    Provide only the refined prompt text. No preamble or explanations.`,
    config: {
      temperature: 0.7,
    },
  });

  return response.text || content;
}
