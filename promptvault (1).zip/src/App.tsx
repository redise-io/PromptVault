import React, { useState, useMemo } from 'react';
import { Sidebar } from './components/Sidebar';
import { PromptEditor } from './components/PromptEditor';
import { PromptCard } from './components/PromptCard';
import { BulkImportModal } from './components/BulkImportModal';
import { SettingsModal } from './components/SettingsModal';
import { Login } from './components/Login';
import { ShortcutChat } from './components/chat/ShortcutChat';
import { useAppStore } from './store/useAppStore';
import { useAuth } from './lib/AuthContext';
import { Prompt } from './types';
import { Plus, Search, UploadCloud, LogOut, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const { user, loading: authLoading, logOut } = useAuth();
  const { prompts, folders, loading: dataLoading, addPrompt, updatePrompt, deletePrompt, addFolder, deleteFolder, incrementUsageCount, setRating } = useAppStore(user?.uid);
  
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [currentTag, setCurrentTag] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [editingPrompt, setEditingPrompt] = useState<Prompt | null | undefined>(undefined);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const uniqueTags = useMemo(() => {
    const allTags = prompts.flatMap(p => p.tags);
    return Array.from(new Set(allTags)).sort();
  }, [prompts]);

  const filteredPrompts = useMemo(() => {
    return prompts.filter(p => {
      const matchesSearch = (p.title || '').toLowerCase().includes(searchQuery.toLowerCase()) || 
                            (p.content || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
                            (p.tags || []).some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesFolder = currentFolderId ? p.folderId === currentFolderId : true;
      const matchesTag = currentTag ? (p.tags || []).includes(currentTag) : true;
      return matchesSearch && matchesFolder && matchesTag;
    });
  }, [prompts, currentFolderId, currentTag, searchQuery]);

  const currentFolder = folders.find(f => f.id === currentFolderId);

  if (authLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-[#F7F7F5]">
        <Loader2 className="animate-spin text-slate-400" size={32} />
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return (
    <div className="flex h-screen w-full bg-slate-50 text-slate-900 font-sans overflow-hidden">
      <Sidebar 
        folders={folders} 
        tags={uniqueTags}
        currentFolderId={currentFolderId} 
        currentTag={currentTag}
        onSelectFolder={(id) => {
          setCurrentFolderId(id);
          setEditingPrompt(undefined);
        }} 
        onSelectTag={(tag) => {
          setCurrentTag(tag);
          setEditingPrompt(undefined);
        }}
        onAddFolder={addFolder} 
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      <AnimatePresence mode="wait">
        {editingPrompt !== undefined ? (
          <motion.div 
            key="editor"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="flex-1 flex flex-col"
          >
            <PromptEditor
              prompt={editingPrompt}
              folders={folders}
              currentFolderId={currentFolderId}
              onSave={(p) => addPrompt(p)}
              onUpdate={updatePrompt}
              onClose={() => setEditingPrompt(undefined)}
            />
          </motion.div>
        ) : (
          <motion.div 
            key="list"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 flex flex-col min-w-0"
          >
            <header className="h-16 border-b border-slate-100 bg-white px-8 flex items-center justify-between shrink-0">
              <div className="relative w-96 flex items-center">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400"><Search size={16} /></span>
                <input 
                  type="text" 
                  placeholder="Search..." 
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="block w-full pl-10 pr-3 py-1.5 border-none bg-slate-50 hover:bg-slate-100 rounded-md text-[14px] focus:outline-none focus:ring-1 focus:ring-slate-200 text-slate-700 transition-colors"
                />
              </div>
              
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsBulkImportOpen(true)}
                  className="bg-white hover:bg-slate-50 text-slate-600 text-sm font-medium px-3 py-1.5 rounded transition-all flex items-center gap-1.5"
                >
                  <UploadCloud size={16} /> Import
                </button>
                <button
                  onClick={() => setEditingPrompt(null)}
                  className="bg-slate-900 hover:bg-black text-white text-sm font-medium px-4 py-1.5 rounded transition-all flex items-center gap-1.5"
                >
                  <Plus size={16} /> New
                </button>
                <div className="h-6 w-px bg-slate-200 mx-2" />
                <button
                  onClick={logOut}
                  className="p-1.5 text-slate-400 hover:text-red-500 rounded hover:bg-red-50 transition-colors"
                  title="Sign Out"
                >
                  <LogOut size={18} />
                </button>
              </div>
            </header>

            <div className="flex-1 overflow-y-auto px-8 md:px-16 pt-12 pb-24 bg-white">
              <div className="flex items-center gap-4 mb-8">
                <h1 className="text-3xl font-bold text-slate-900">
                  {currentFolder ? currentFolder.name : currentTag ? `#${currentTag}` : 'My Prompts'}
                </h1>
                {dataLoading && <Loader2 className="animate-spin text-slate-300" size={20} />}
              </div>

              {filteredPrompts.length === 0 && !dataLoading ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 gap-4 mt-12">
                  <p className="text-sm">No pages inside.</p>
                  <button
                    onClick={() => setEditingPrompt(null)}
                    className="text-slate-900 border border-slate-200 px-3 py-1.5 rounded text-sm hover:bg-slate-50 font-medium transition-colors"
                  >
                    + Add a page
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {filteredPrompts.map(prompt => (
                    <PromptCard 
                      key={prompt.id} 
                      prompt={prompt} 
                      onEdit={setEditingPrompt}
                      onDelete={deletePrompt}
                      onRate={setRating}
                      onCopyAction={incrementUsageCount}
                    />
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <BulkImportModal 
        isOpen={isBulkImportOpen} 
        onClose={() => setIsBulkImportOpen(false)} 
        currentFolderId={currentFolderId} 
      />

      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
      />

      <ShortcutChat 
        prompts={prompts}
        folders={folders}
        onSelectPrompt={(p) => {
          setEditingPrompt(p);
        }}
        onSelectFolder={(id) => {
          setCurrentFolderId(id);
          setCurrentTag(null);
          setEditingPrompt(undefined);
        }}
        onNewPrompt={() => setEditingPrompt(null)}
      />
    </div>
  );
}
